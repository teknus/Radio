rm client* server
