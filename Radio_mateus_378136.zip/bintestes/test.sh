cd ..
go build radio/server/sever.go
mv server serverb
mv serverb radio/
cd radio
